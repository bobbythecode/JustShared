package com.cigna.samples;

public class SimpleLogger {
	public static void logInfo(String message) {
		System.out.println(message);
	}
	
	public static void logWarning(String message) {
		System.out.println(message);
	}

	public static void logError(String message) {
		System.out.println(message);
	}
	
}
