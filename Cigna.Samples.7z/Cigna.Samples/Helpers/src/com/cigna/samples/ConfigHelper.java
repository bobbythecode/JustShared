package com.cigna.samples;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class ConfigHelper {
	static Properties prop = new Properties();
	static InputStream input = null;

	private static String dataFile;
	
	static {
		try {
			readCfgFile();
			
		} catch (IOException e) {
			SimpleLogger.logError(e.getMessage());
			
		}
	}
	
	public static String getDataFile() {
		return dataFile;
	}

	public static void readCfgFile() throws IOException {
		try {

			String cfgFile = System.getProperty("user.dir") + "/config.properties";
			input = new FileInputStream(cfgFile);
			if(input==null){
				throw new FileNotFoundException(cfgFile);
			}

			prop.load(input);
			dataFile = prop.getProperty("data_file");

		} catch (IOException e) {
			SimpleLogger.logError(e.getMessage());
			throw e;
			
		} finally {
			if (input != null) {
				try {
					input.close();

				} catch (IOException e) {
					SimpleLogger.logError(e.getMessage());

				}
			}
		}		
	}
}

