package com.cigna.samples;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.management.OperationsException;

import com.cigna.samples.SimpleLogger;

public class FileHelper {
	public static List<String> read(String fileName) throws Exception {		
		try {
			List<String> resultSet = new ArrayList<String>();
			BufferedReader br = new BufferedReader(new FileReader(fileName));

			try {
				String line = br.readLine();

				while (line != null) {
					resultSet.add(line);
					line = br.readLine();
				}

				if(resultSet.isEmpty()) {
					throw new OperationsException("No data");
				}

				return resultSet;

			} catch(Exception e) {
				throw e;

			} finally {
				br.close();
			}	

		} catch (IOException e) {
			SimpleLogger.logError(e.getStackTrace().toString());
			throw e;

		} catch(Exception e) {
			SimpleLogger.logError(e.getStackTrace().toString());
			throw e;
		}
	}

}
