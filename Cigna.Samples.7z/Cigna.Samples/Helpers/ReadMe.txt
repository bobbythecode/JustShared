File Structure Descriptions:
*** Needs Maven Builder Tools
-	src folder:
	Contains source code of the sample.

- 	target folder:
	Contains the result files of Maven building.
	
	
-	build.cmd:
	The file to build the target files.
	
	