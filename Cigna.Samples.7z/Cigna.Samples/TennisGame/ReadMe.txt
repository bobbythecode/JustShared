File Structure Descriptions:
*** Needs Maven Builder Tools
-	src folder:
	Contains source code of the sample.

-	test folder:
	Contains source code of test cases of the sample.

- 	target folder:
	Contains the result files of Maven building.
	
-	config.properties:
	As a configuration file to set the default data input file.
	
- 	data.txt:
	A sample of data for testing.
	
-	build.cmd:
	The file to build the target files.
	
- 	run.cmd:
	For running the application.
	