package com.cigna.samples;

import java.security.InvalidParameterException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Court implements ICourt {
	private final Player playerA = new Player("A");
	private final Player playerB = new Player("B");

	private final List<String> playingLog = new ArrayList<String>(); 
	
	public static void main(String[] args) throws Exception {
		try {
			new Court().run();

		} catch(Exception e) {
			Logger.logError(e.getMessage());
			throw e;
		}
	}

	private void printTitle() {
		System.out.println("[]========== The Simple Tennis Game ==========[]");
		System.out.println("*** Input Data: " + ConfigHelper.getDataFile());
		System.out.println("Go...\n");
	}
	
	@Override
	public void run() throws Exception {
		printTitle();

		try {			
			Player winner = null;
			List<String> games = getMatches();
			
			System.out.println("Input file format:");
			games.forEach((s) -> {
				System.out.println(s);
			});			
			
			for(String g : games) {
				winner = play(g);
			}
			
			if(winner == null) {
			} else {
				printScore();
			}
			
		} catch(Exception e) {
			Logger.logError(e.getMessage());
			throw e;
		}	
		
		System.out.println("\n...end...");
	}

	private Player play(String game) throws Exception {
		Player winner = null;
		try {
			List<String> tokens = getTokens(game);
			
			playerA.reset();
			playerB.reset();
						
			for(String k : tokens) {
				switch(k) {
					case "A":
						playerA.countScore();

						if(	playerA.getScore() == ScoreSteps.Score40 &&
							playerB.getScore() == ScoreSteps.Score40 || 
							playerB.getScore() == ScoreSteps.Adv) {
							
							addPlayingLog(playerA);						

							playerA.redeuce();
							playerB.redeuce();
							
						} else {
							addPlayingLog(playerA);						
						}

						if(playerA.getScore() == ScoreSteps.Deuce) {
							addPlayingLog("DUCE");
						}
						
						break;
						
					case "B":
						playerB.countScore();

						if( playerB.getScore() == ScoreSteps.Score40 &&
							playerA.getScore() == ScoreSteps.Score40 || 
							playerA.getScore() == ScoreSteps.Adv) {

							addPlayingLog(playerB);
							
							playerA.redeuce();
							playerB.redeuce();
							
						} else {
							addPlayingLog(playerB);
						}
						
						if(playerB.getScore() == ScoreSteps.Deuce) {
							addPlayingLog("DUCE");
						}

						break;
						
					default:
						addPlayingLog("\n" + tokens.get(0));
						break;
				}
			}
			
			if(playerA.getScore() == ScoreSteps.Win) {
				winner = playerA;
				
			} else if(playerB.getScore() == ScoreSteps.Win) {
				winner = playerB;
			 }

		} catch(Exception e) {
			Logger.logError(e.getMessage());
			throw e;
		}
		
		return winner;
	}

	private void addPlayingLog(Player player) {
		String logString = String.format("%s: %s", player.getName(), player.getScore().getString());
		playingLog.add(logString);
	}

	private void addPlayingLog(String title) {
		playingLog.add(title);
	}
	
	private List<String> getTokens(String game) throws Exception {
		try {
			List<String> tokens = new ArrayList<String>();
			
			if(game == null || game.isEmpty()) {
				throw new IllegalArgumentException("No Data");
			}

			String[] tmp = game.split("\\s+");
			for(String k : tmp) {
				validateToken(k);
				tokens.add(k.trim());
			}
			
			return tokens;
			
		}catch(Exception e) {
			Logger.logError(e.getMessage());
			throw e;
		}
	}

	private void validateToken(String token) throws Exception {
		try {
			if(!isToken(token)){
				throw new InvalidParameterException("Invalid Token");
			}			
			
		} catch(Exception e) {
			Logger.logError(e.getMessage());
			throw e;
		}
	}

	private boolean isToken(String token) throws Exception {
		try {
			Pattern pattern = Pattern.compile("[AB]");
			Matcher matcher = pattern.matcher(token);
			if(matcher.find()){
				return true;
			}
			
			
		} catch(Exception e) {
			Logger.logError(e.getMessage());
			throw e;
		}
		
		return false;
	}
	
	@Override
	public void printScore() {
		try {
			System.out.println("\n\nOutput format:");
			for(String s : playingLog) {
				System.out.println(s);
			}
			
		} catch(Exception e) {
			Logger.logError(e.getMessage());
			throw e;
		}			
	}

	@Override
	public List<String> getMatches() throws Exception {
		try {
			return FileHelper.read(ConfigHelper.getDataFile());
			
		} catch(Exception e) {
			Logger.logError(e.getMessage());
			throw e;
		}
	}
}
