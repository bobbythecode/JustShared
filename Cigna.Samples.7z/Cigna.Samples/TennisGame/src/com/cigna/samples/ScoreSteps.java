package com.cigna.samples;

public enum ScoreSteps {
	Score0(0), Score15(15), Score30(30), Score40(40), Deuce(100), Adv(200), Win(500);
	
	private final int value;
    private ScoreSteps(int value) {
        this.value = value;
    }
    
	public int getInt() {
        return value;
    }
	
	public String getString() {		
		switch(value) {
			case 0: return "0";
			case 15: return "15";
			case 30: return "30";
			case 40: return "40";
			case 100: return "ADV";
			case 200: return "ADV";
			case 500: return "WIN";
			default: return "";	
		}
    }		
}
