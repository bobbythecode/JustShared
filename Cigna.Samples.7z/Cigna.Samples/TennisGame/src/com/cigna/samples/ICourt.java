package com.cigna.samples;

import java.util.List;

public interface ICourt {

	void run() throws Exception;

	void printScore();

	List<String> getMatches() throws Exception;

}