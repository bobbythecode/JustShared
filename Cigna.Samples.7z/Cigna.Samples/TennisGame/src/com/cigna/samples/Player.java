package com.cigna.samples;

public class Player {
	private String name;
	
	private ScoreSteps score = ScoreSteps.Score0;

	public Player(String name) {
		this.name = name;
	}
	
	public void countScore() {
		switch(score) {
			case Score0:
				score = ScoreSteps.Score15;
				break;
				
			case Score15:
				score = ScoreSteps.Score30;
				break;

			case Score30:
				score = ScoreSteps.Score40;
				break;
			
			case Score40:
				score = ScoreSteps.Win;
				break;

			case Deuce:
				score = ScoreSteps.Adv;
				break;

			case Adv:
				score = ScoreSteps.Win;
				break;
				
			case Win:
				break;
				
		}
	}

	public void reset() {
		score = ScoreSteps.Score0;
	}
	
	public void redeuce() {
		score = ScoreSteps.Deuce;
	}

	public final ScoreSteps getScore() {
		return score;
	}

	public String getName() {
		return name;
	}
}
