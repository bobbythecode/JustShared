package com.cigna.samples;

import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.spy;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;


///

@RunWith(MockitoJUnitRunner.class)
public class GameTest {

	ICourt courtSpy;
	
	@Before
	public void setUp() throws Exception {
		courtSpy = spy(new Court());
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void FindWinner_BestCaseParameters_ResultOfMatch() throws Exception {
		Map<String, String> testList = new HashMap<String, String>();
		// Input Data <----> Expecting Results
		testList.put("A A A A", "A: 15,A: 30,A: 40,A: WIN");
		testList.put("A B A B A A", "A: 15,B: 15,A: 30,B: 30,A: 40,A: WIN");
		testList.put("B B A A A B A B B B", "B: 15,B: 30,A: 15,A: 30,A: 40,B: 40,DUCE,A: ADV,B: ADV,DUCE,B: ADV,B: WIN");
						
		List<String> mockedArgs = new ArrayList<String>();
		for(Entry<String, String> d : testList.entrySet()) {
			mockedArgs.add(d.getKey());
		}
		
		Mockito.doReturn(mockedArgs).when(courtSpy).getMatches();
		courtSpy.run();

	    
	    List<String> actualResults = getPrivateField(courtSpy, "playingLog");
	    String actualString = String.join(",", actualResults);
	    
		for(Entry<String, String> d : testList.entrySet()) {
			assertTrue(actualString.contains(d.getValue()));
		}
	}	

	@Test
	public void FindWinner_RandomPattternParameters_StillKeepCorrectResult() throws Exception {
		Map<String, String> matches = new HashMap<String, String>();
		// Input Data <----> Expecting Results
		matches.put("A  A  A  A ", "A: 15,A: 30,A: 40,A: WIN");
		matches.put("A B    A  B  A A", "A: 15,B: 15,A: 30,B: 30,A: 40,A: WIN");
		matches.put("B   B  A A  A  B  A B B B", "B: 15,B: 30,A: 15,A: 30,A: 40,B: 40,DUCE,A: ADV,B: ADV,DUCE,B: ADV,B: WIN");
		matches.put("B  A A  A  B  A B B B", "B: 15,B: 30,A: 15,A: 30,A: 40,B: 40,DUCE,A: ADV,B: ADV,DUCE,B: ADV,B: WIN");
						
		List<String> mockedArgs = new ArrayList<String>();
		for(Entry<String, String> d : matches.entrySet()) {
			mockedArgs.add(d.getKey());
		}
		
		Mockito.doReturn(mockedArgs).when(courtSpy).getMatches();
		courtSpy.run();

	    
	    List<String> actualResults = getPrivateField(courtSpy, "playingLog");
	    String actualString = String.join(",", actualResults);
	    
		for(Entry<String, String> d : matches.entrySet()) {
			assertTrue(actualString.contains(d.getValue()));
		}
	}	

	@Test
	public void FindWinner_RandomTest_StillKeepCorrectResult() throws Exception {
		Map<String, String> matches = new HashMap<String, String>();
		// Input Data <----> Expecting Results
		matches.put("A A A B A ", "A: 15,A: 30,A: 40,B: 15,A: WIN");
//		matches.put("A B A B A B A B B A A A", "A: 15,B: 15,A: 30,B: 30,A: 40,A: WIN");
						
		List<String> mockedArgs = new ArrayList<String>();
		for(Entry<String, String> d : matches.entrySet()) {
			mockedArgs.add(d.getKey());
		}
		
		Mockito.doReturn(mockedArgs).when(courtSpy).getMatches();
		courtSpy.run();

	    
	    List<String> actualResults = getPrivateField(courtSpy, "playingLog");
	    String actualString = String.join(",", actualResults);
	    
		for(Entry<String, String> d : matches.entrySet()) {
			assertTrue(actualString.contains(d.getValue()));
		}
	}	
	
	@SuppressWarnings("unchecked")
	private <T,V> T getPrivateField(V obj, String fieldName) throws NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException {
	    Field privateField = Court.class.getDeclaredField(fieldName);
	    privateField.setAccessible(true);
	    T value = (T)privateField.get(obj);
		
	    return value;
	}
}
