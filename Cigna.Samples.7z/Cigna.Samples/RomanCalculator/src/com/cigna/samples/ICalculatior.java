package com.cigna.samples;

import java.util.List;

public interface ICalculatior {

	void run() throws Exception;

	List<String> getInputs() throws Exception;

	void printResults(String args, int result);

}