package com.cigna.samples;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Constants {
	public static class Operands {
		public static final Character I = 'I';
		public static final Character V = 'V';
		public static final Character X = 'X';
		public static final Character L = 'L';
		public static final Character C = 'C';
		public static final Character D = 'D';
		public static final Character M = 'M';
	}
	
	public static final String ValidOpeators = "+";
	public static final String ValidCharacters = "+IVXLCMD";
	
	public static final Map<Character, Integer> numeralTable;
	public static final List<Integer> stepValuTable;

	static {
		numeralTable = new HashMap<Character, Integer>();
		numeralTable.put(Operands.I, 1);
		numeralTable.put(Operands.V, 5);
		numeralTable.put(Operands.X, 10);
		numeralTable.put(Operands.L, 50);
		numeralTable.put(Operands.C, 100);
		numeralTable.put(Operands.D, 500);
		numeralTable.put(Operands.M, 1000);
		
		
		stepValuTable = new ArrayList<Integer>();
		stepValuTable.add(1);
		stepValuTable.add(5);
		stepValuTable.add(10);
		stepValuTable.add(50);
		stepValuTable.add(100);
		stepValuTable.add(500);
		stepValuTable.add(1000);
	}
}
