package com.cigna.samples;

import java.io.IOException;
import java.security.InvalidParameterException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Calculator implements ICalculatior {

	public static void main(String[] args) throws Exception {
		new Calculator().run();	
	}

	public Calculator() throws IOException {		
    }
	
	private void printTitle() {
		System.out.println("[]========== The Simple Roman Calculator ==========[]");
		System.out.println("*** There is a SUM function only");
		System.out.println("*** Input Data: " + ConfigHelper.getDataFile());
		System.out.println("Go...\n");
	}
	
	@Override
	public void run() throws Exception {
		printTitle();
		
		List<String> inputs = getInputs();		
		inputs.forEach((data) -> {
			int result = calculate(data);
			printResults(data, result);
		});
		
		System.out.println("\n...end...");
	}

	public void printResults(String data, int result) {
		String romanString  = convertFromDecimal(result);
		System.out.println(String.format("Input: %s = %s", data, romanString));
	}

	private int calculate(String data) {
		try {
			List<Object> validTokens = convertToDecimal(getTokens(data));
			return sum(validTokens);

		} catch(Exception e) {
			SimpleLogger.logError(e.getMessage());
			throw e;
		}
	}

	private int sum(List<Object> validTokens) {
		try {
			if(validTokens == null || validTokens.isEmpty()) {
				return 0;
			}
			
			int total = (int) validTokens.get(0);

			for(int i=1; i<validTokens.size(); i++) {			 
				total += (int) validTokens.get(i);
			}

			return total;

		}catch(Exception e) {
			SimpleLogger.logError(e.getMessage());
			throw e;
		}
	}

	private List<Object> convertToDecimal(List<String> tokens) {
		try {
			List<Object> validTokens = new ArrayList<Object>();

			tokens.forEach((k) -> {
				Integer token = getDecimalValue(k.trim());
				if(token != null) {
					validTokens.add(token);
				}
			});


			return validTokens;

		} catch(Exception e) {
			SimpleLogger.logError(e.getMessage());
			throw e;

		}
	}

	public String convertFromDecimal(Integer data) {
		StringBuilder result = new StringBuilder();

		try {

			for(int i = Constants.stepValuTable.size() -1; i >= 0;){
				int valueStep = Constants.stepValuTable.get(i);
				int diff = data - valueStep;

				if(diff < 0) {
					i--;
					continue;					
				}
				
				if(data >= 1000) {
					diff = data - 1000;
					result.append("M");
				} else if(data >= 900) {
					diff = data - 900;
					result.append("CM");				
				} else if(data >= 500 && data < 900) {
					diff = data - 500;
					result.append("D"); 
				} else if(data >= 400 && data < 500) {
					diff = data - 400;
					result.append("CD");
				} else if(data >= 100) {
					diff = data - 100;
					result.append("C");
				} else if(data >= 90 && data < 100) {
					diff = data - 90;
					result.append("XC");
				} else if(data >= 50) {
					diff = data - 50;
					result.append("L");
				} else if(data >= 40 && data < 50) {
					diff = data - 40;
					result.append("XL");
				} else if(data >= 10 && data < 40) {
					diff = data - 10;
					result.append("X");
				} else if(data == 9) {
					diff = data - 9;
					result.append("IX");
				} else if(data >= 5 && data < 9) {
					diff = data - 5;
					result.append("V");
				} else if(data == 4) {
					diff = data - 4;
					result.append("IV");
				} else if(data >= 1 && data < 4) {
					diff = data - 1;
					result.append("I");
				}

				data = diff;

			}

		} catch(Exception e) {
			SimpleLogger.logError(e.getMessage());
			throw e;

		}

		return result.toString();
	}

	private Integer getDecimalValue(String data) {
		try {
			if(!isOperand(data)){
				return null;
			}

			char[] chars = data.toCharArray();

			Integer total = 0;
			int tmp = 0;
			int last = Integer.MAX_VALUE;


			for(int i=0; i<chars.length; i++) {
				tmp = Constants.numeralTable.get(chars[i]);
				if(tmp <= last) {
					total += tmp;
				} else {
					total += tmp - (2*last);
				}

				last = tmp;
			}

			return total;

		} catch(Exception e) {
			SimpleLogger.logError(e.getMessage());
			throw e;

		}
	}

	private Boolean isOperand(String data) {
		try {
			String patternStr = String.format("[%s]", Constants.ValidOpeators);
			Pattern pattern = Pattern.compile(patternStr);
			Matcher matcher = pattern.matcher(data);
			if(matcher.find()){
				return false;
			}

			return true;

		}catch(Exception e) {
			SimpleLogger.logError(e.getMessage());
			throw e;
		}
	}

	private List<String> getTokens(String data) {	
		try {

			validateArgs(data);
			List<String> tokens = new ArrayList<String>();

			int index = 0;
			do{
				index =  indexOf(data);
				if(index < 0) {
					index = data.length();
				}

				String subString = data.substring(0, index);
				tokens.add(subString);

				if((index+1) > data.length()) {
					break;
				}
				
				data = data.substring(index+1, data.length());

			} while(index > 0);

			return tokens;

		} catch(Exception e) {
			SimpleLogger.logError(e.getMessage());
			throw e;
		}
	}

	private int indexOf(String target) {
		try {
			String patternStr = String.format("[%s]", Constants.ValidOpeators);
			Pattern pattern = Pattern.compile(patternStr);
			Matcher matcher = pattern.matcher(target);
			if(matcher.find()){
				return matcher.start();
			}

			return -1;
			
		} catch(Exception e) {
			SimpleLogger.logError(e.getMessage());
			throw e;
		}
	}

	private void validateArgs(String data) {
		try {
			if(data == null || data.isEmpty()) {
				throw new InvalidParameterException("No data");
			}

			data = data.toUpperCase();
			data = data.replaceAll("\\s+", "");

			String regexString = String.format("[%s]*", Constants.ValidCharacters);
			Pattern pattern = Pattern.compile(regexString);
			Matcher matcher = pattern.matcher(data);

			if(!matcher.matches()) {
				throw new InvalidParameterException("The string contain invalid character(s)");
			}	

		} catch(Exception e) {
			SimpleLogger.logError(e.getMessage());
			throw e;
		}
	}


	@Override
	public List<String> getInputs() throws Exception {
		return FileHelper.read(ConfigHelper.getDataFile());				
	}
}
