package com.cigna.sample.cigna.test;

import static org.mockito.Mockito.spy;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import com.cigna.samples.Calculator;
import com.cigna.samples.ICalculatior;

///

@RunWith(MockitoJUnitRunner.class)
public class CalculatorTest {

	ICalculatior calSpy;
	
	@Before
	public void setUp() throws Exception {
		calSpy = spy(new Calculator());
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void Sum_BestCaseParameters_ResultOfSum() throws Exception {
		Map<String, Integer> testList = new HashMap<String, Integer>();
		// Input Data <----> Expecting Results
		testList.put("II+II", 4);
		testList.put("XX+II", 22);
		testList.put("XIV+LX", 74);
		testList.put("V+V", 10);
						
		List<String> mockedArgs = new ArrayList<String>();
		for(Entry<String, Integer> d : testList.entrySet()) {
			mockedArgs.add(d.getKey());
		}
		
		Mockito.doReturn(mockedArgs).when(calSpy).getInputs();
		calSpy.run();

		for(Entry<String, Integer> d : testList.entrySet()) {
			Mockito.verify(calSpy).printResults(d.getKey(), d.getValue());
		}
	}
	
	@Test
	public void Sum_ValidParameters_ResultOfSum() throws Exception {
		Map<String, Integer> testList = new HashMap<String, Integer>();
		// Input Data <----> Expecting Results
		testList.put("II + II", 4);
		testList.put("XX+ II", 22);
		testList.put("XIV +LX", 74);
		testList.put("V+ V", 10);
		
		List<String> mockedArgs = new ArrayList<String>();
		for(Entry<String, Integer> d : testList.entrySet()) {
			mockedArgs.add(d.getKey());
		}
		
		Mockito.doReturn(mockedArgs).when(calSpy).getInputs();
		calSpy.run();
		
		for(Entry<String, Integer> d : testList.entrySet()) {
			Mockito.verify(calSpy).printResults(d.getKey(), d.getValue());
		}		
	}
	
	@Test
	public void Sum_CriticalParameters_CorrectResult() throws Exception {
		Map<String, Integer> testList = new HashMap<String, Integer>();
		// Input Data <----> Expecting Results
		testList.put("CM + I", 901);
		testList.put("MDCCC + I", 1801);
		testList.put("DCCCXC + I", 891);
		testList.put("DCCVII + I", 708);
		testList.put("XCIX + I", 100);
		testList.put("XCVIII + I", 99);
		testList.put("XCVII + I", 98);
		testList.put("XCVI + I", 97);
		testList.put("XCV + I", 96);
		testList.put("LXXVIII + I", 79);
		testList.put("XCI + I", 92);
		testList.put("LXXXVIII + I", 89);
		testList.put("LVIII + I", 59);
		testList.put("LVIII", 58);
				
		List<String> mockedArgs = new ArrayList<String>();
		for(Entry<String, Integer> d : testList.entrySet()) {
			mockedArgs.add(d.getKey());
		}
		
		
		Mockito.doReturn(mockedArgs).when(calSpy).getInputs();
		calSpy.run();
		
		for(Entry<String, Integer> d : testList.entrySet()) {
			Mockito.verify(calSpy).printResults(d.getKey(), d.getValue());
		}
		
	}	

	@Test
	public void Sum_IncorrectParameters_ReturnZero() throws Exception {
		Map<String, Integer> testList = new HashMap<String, Integer>();
		// Input Data <----> Expecting Results
		testList.put("+LVIII", 0);
				
		List<String> mockedArgs = new ArrayList<String>();
		for(Entry<String, Integer> d : testList.entrySet()) {
			mockedArgs.add(d.getKey());
		}
		
		Mockito.doReturn(mockedArgs).when(calSpy).getInputs();
		calSpy.run();

		for(Entry<String, Integer> d : testList.entrySet()) {
			Mockito.verify(calSpy).printResults(d.getKey(), d.getValue());
		}
		
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void Sum_WorstCaseParameters_ExpectedException() throws Exception {
		List<String> mockedArgs = new ArrayList<String>();
		mockedArgs.add("hello");
		
		Mockito.doReturn(mockedArgs).when(calSpy).getInputs();
		calSpy.run();
		
	}		
	
}
